using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;

namespace IngestHealthData
{
    public class Function1
    {
        private readonly ILogger<Function1> _logger;

        public Function1(ILogger<Function1> logger)
        {
            _logger = logger;
        }

        [Function("Function1")]
        public IActionResult Run([HttpTrigger(AuthorizationLevel.Function, "get", "post")] HttpRequest req)
        {
            _logger.LogInformation("C# HTTP trigger function processed a request.");
            return new OkObjectResult("Welcome to Azure Functions!");

        }
    }
}

/*
 
// Initialize the Cosmos client
endpoint = ""
key = "1zhElpsVNkz8yeSFrjs1S7D-4wXjRrhl85dG6tQd9zxUAzFuFw4XWQ=="
client = CosmosClient(endpoint, key)

// Create a database and container if they do not exist
database_name = 'HealthDataDB'
container_name = 'HealthDataContainer'
database = client.create_database_if_not_exists(id=database_name)
container = database.create_container_if_not_exists(
    id=container_name,
    partition_key=PartitionKey(path="/patientId"),
    offer_throughput=400
)

def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('IngestHealthData function processed a request.')

    try:
        // Parse the JSON data from the request body
        req_body = req.get_json()
        patient_id = req_body.get('patientId')
        health_data = req_body.get('healthData')

        if not patient_id or not health_data:
            return func.HttpResponse(
                "Invalid input. Please provide 'patientId' and 'healthData'.",
                status_code=400
            )

        // Create a new item in the container
        item = {
            'id': str(uuid.uuid4()),
            'patientId': patient_id,
            'healthData': health_data,
            'timestamp': datetime.datetime.utcnow().isoformat()
        }
        container.create_item(body=item)

        return func.HttpResponse(
            "Health data ingested successfully.",
            status_code=200
        )

    except Exception as e:
        logging.error(f"Error ingesting health data: {e}")
        return func.HttpResponse(
            "Failed to ingest health data.",
            status_code=500
        )
*/

/*
 /Function to process incoming event hub messages
def process_event(event):
    # Assuming event is JSON formatted health data
    health_data = json.loads(event)
    patient_id = health_data.get('patientId')
    
    if not patient_id:
        logging.error("Missing patientId in health data")
        return

    //Create a new item in the container
    item = {
        'id': str(uuid.uuid4()),
        'patientId': patient_id,
        'healthData': health_data,
        'timestamp': datetime.datetime.utcnow().isoformat()
    }
    container.create_item(body=item)
    logging.info(f"Ingested data for patientId: {patient_id}")

//Azure Function triggered by Event Hub
def main(event: func.EventHubEvent):
    logging.info('IngestHealthData function triggered')
    for event_data in event.get_body():
        process_event(event_data)
 */